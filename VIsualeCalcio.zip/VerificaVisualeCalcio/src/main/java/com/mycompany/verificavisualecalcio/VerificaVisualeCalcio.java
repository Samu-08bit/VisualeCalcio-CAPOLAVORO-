/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.verificavisualecalcio;

/**
 *
 * @author 4C
 */
public class VerificaVisualeCalcio {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
